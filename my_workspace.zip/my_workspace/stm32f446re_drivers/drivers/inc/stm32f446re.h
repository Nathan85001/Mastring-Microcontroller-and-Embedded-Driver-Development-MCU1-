/*
 * stm32f446re.h
 *
 *  Created on: Sep 21, 2023
 *      Author: nathan
 */

#ifndef INC_STM32F446RE_H_
#define INC_STM32F446RE_H_

#include <stdint.h>

#define __vo									volatile

/*1. the base addresses of the different memories at stm32f446-re */
#define FLASH_BASEADDR							0x08000000U //the flash memory base address for stm32f446-re
#define SRAM1_BASEADDR							0x20000000U //the SRAM1 base address for stm32f446-re
#define SRAM2_BASEADDR							0x2001C000U //the SRAM2 base address for stm32f446-re
#define ROM										0x1FFF0000U // named as system memory at data sheet
#define SRAM 									SRAM1_BASEADDR //that's because the SRAM1 is the main SRAM so added this line to explain that

/*2. the base addresses of the different bus domains at stm32f446-re */
#define AHB1_BASEADDR							0x40020000U	//the advanced high-performance bus 1 base address for stm32f446-re
#define AHB2_BASEADDR							0x50000000U //the advanced high-performance bus 2 base address for stm32f446-re
#define AHB3_BASEADDR							0x60000000U //the advanced high-performance bus 3 base address for stm32f446-re
#define APB1_BASEADDR							0x40000000U //the advanced peripheral bus 1 base address for stm32f446-re
#define APB2_BASEADDR							0x40010000U //the advanced peripheral bus 2 base address for stm32f446-re

/*3. the base addresses of the peripherals at AHB1 */
#define GPIOA_BASEADDR							(AHB1_BASEADDR + 0x00000)
#define GPIOB_BASEADDR							(AHB1_BASEADDR + 0x00400)
#define GPIOC_BASEADDR							(AHB1_BASEADDR + 0x00800)
#define GPIOD_BASEADDR							(AHB1_BASEADDR + 0x00C00)
#define GPIOE_BASEADDR							(AHB1_BASEADDR + 0x01000)
#define GPIOF_BASEADDR							(AHB1_BASEADDR + 0x01400)
#define GPIOG_BASEADDR							(AHB1_BASEADDR + 0x01800)
#define GPIOH_BASEADDR							(AHB1_BASEADDR + 0x01C00)
#define CRC_BASEADDR							(AHB1_BASEADDR + 0x23000)
#define RCC_BASEADDR							(AHB1_BASEADDR + 0x23800)
#define FLASH_INTERFACE_REGISTER_BASEADDR		(AHB1_BASEADDR + 0x23C00)
#define BKPSRAM_BASEADDR						(AHB1_BASEADDR + 0x24000)
#define DMA1_BASEADDR							(AHB1_BASEADDR + 0x26000)
#define DMA2_BASEADDR							(AHB1_BASEADDR + 0x26400)
#define USB_OTG_HS_BASEADDR						(AHB1_BASEADDR + 0x40000)

/*4. the base addresses of the peripherals at AHB2*/
#define USB_OTG_FS_BASEADDR						(AHB2_BASEADDR + 0x00000)
#define DCMI_BASEADDR							(AHB2_BASEADDR + 0x50000)

/*5. the base addresses of the peripherals at AHB3*/
#define FMC_BANK1_BASEADDR						(AHB3_BASEADDR + 0x00000000)
#define FMC_BANK3_BASEADDR						(AHB3_BASEADDR + 0x20000000)
#define QUAD_SPI_BASEADDR						(AHB3_BASEADDR + 0x30000000)
#define FMC_CONTROL_REGISTER_BASEADDR			(AHB3_BASEADDR + 0x40000000)
#define QUAD_SPI_CONTROL_REGISTER_BASEADDR		(AHB3_BASEADDR + 0x40001000)
#define FMC_BANK5_BASEADDR						(AHB3_BASEADDR + 0x60000000)
#define FMC_BANK6_BASEADDR						(AHB3_BASEADDR + 0x70000000)

/*6. the base addresses of the peripherals at APB1*/
#define TIM2_BASEADDR							(APB1_BASEADDR + 0x0000)
#define TIM3_BASEADDR							(APB1_BASEADDR + 0x0400)
#define TIM4_BASEADDR							(APB1_BASEADDR + 0x0800)
#define TIM5_BASEADDR							(APB1_BASEADDR + 0x0C00)
#define TIM6_BASEADDR							(APB1_BASEADDR + 0x1000)
#define TIM7_BASEADDR							(APB1_BASEADDR + 0x1400)
#define TIM12_BASEADDR							(APB1_BASEADDR + 0x1800)
#define TIM13_BASEADDR							(APB1_BASEADDR + 0x1C00)
#define TIM14_BASEADDR							(APB1_BASEADDR + 0x2000)
#define RTC_BKP_REGISTERS_BASEADDR				(APB1_BASEADDR + 0x2800)
#define WWDG_BASEADDR							(APB1_BASEADDR + 0x2C00)
#define IWDG_BASEADDR							(APB1_BASEADDR + 0x3000)
#define SPI2_I2S2_BASEADDR						(APB1_BASEADDR + 0x3800)
#define SPI3_I2S3_BASEADDR						(APB1_BASEADDR + 0x3C00)
#define SPDIFRX_BASEADDR						(APB1_BASEADDR + 0x4000)
#define USART2_BASEADDR							(APB1_BASEADDR + 0x4400)
#define USART3_BASEADDR							(APB1_BASEADDR + 0x4800)
#define UART4_BASEADDR							(APB1_BASEADDR + 0x4C00)
#define UART5_BASEADDR							(APB1_BASEADDR + 0x5000)
#define I2C1_BASEADDR							(APB1_BASEADDR + 0x5400)
#define I2C2_BASEADDR							(APB1_BASEADDR + 0x5800)
#define I2C3_BASEADDR							(APB1_BASEADDR + 0x5C00)
#define FMPI2C1_BASEADDR						(APB1_BASEADDR + 0x6000)
#define CAN1_BASEADDR							(APB1_BASEADDR + 0x6400)
#define CAN2_BASEADDR							(APB1_BASEADDR + 0x6800)
#define HDMI_CEC_BASEADDR						(APB1_BASEADDR + 0x6C00)
#define PWR_BASEADDR							(APB1_BASEADDR + 0x7000)
#define DAC_BASEADDR							(APB1_BASEADDR + 0x7400)

/*7. the base addresses of the peripherals at APB2*/
#define TIM1_BASEADDR							(APB2_BASEADDR + 0x0000)
#define TIM8_BASEADDR							(APB2_BASEADDR + 0x0400)
#define USART1_BASEADDR							(APB2_BASEADDR + 0x1000)
#define USART6_BASEADDR							(APB2_BASEADDR + 0x1400)
#define ADC1_ADC2_ADC3_BASEADDR					(APB2_BASEADDR + 0x2000)
#define SDIO_BASEADDR							(APB2_BASEADDR + 0x2C00)
#define SPI1_BASEADDR							(APB2_BASEADDR + 0x3000)
#define SPI4_BASEADDR							(APB2_BASEADDR + 0x3400)
#define SYSCFG_BASEADDR							(APB2_BASEADDR + 0x3800)
#define EXTI_BASEADDR							(APB2_BASEADDR + 0x3C00)
#define TIM9_BASEADDR							(APB2_BASEADDR + 0x4000)
#define TIM10_BASEADDR							(APB2_BASEADDR + 0x4400)
#define TIM11_BASEADDR							(APB2_BASEADDR + 0x4800)
#define SAI1_BASEADDR							(APB2_BASEADDR + 0x5800)
#define SAI2_BASEADDR							(APB2_BASEADDR + 0x5C00)

/*8. peripheral register definition structures */
/*
 * Note: Registers of a peripheral are specific to MCU
 * e.g : Number of Registers of SPI peripheral of STM32F4x family of MCUs may be different (more or less)
 * compared to number of registers of SPI peripheral of STM32Lx or STM32F0x family of MCUs
 * Please check your device RM
 */

typedef struct
{
	__vo uint32_t MODER;	//GPIOA port mode register
	__vo uint32_t OTYPER;	//GPIOA port output type register
	__vo uint32_t OSPEEDER;	//GPIOA port output speed register
	__vo uint32_t PUPDR;	//GPIOA port pull-up/pull-down register
	__vo uint32_t IDR;		//GPIOA port input data register
	__vo uint32_t ODR;		//GPIOA port output data register
	__vo uint32_t BSRR;		//GPIOA port bit set/reset register
	__vo uint32_t LCKR;		//GPIOA port configuration lock register
	__vo uint32_t AFR[2];		//GPIOA alternate function register

}GPIO_RegDef_t;

typedef struct
{
	__vo uint32_t CR;			//RCC clock control register
	__vo uint32_t PLLCFGR;		//RCC PLL configuration register
	__vo uint32_t CFGR;			//RCC clock configuration register
	__vo uint32_t CIR;			//RCC clock interrupt register
	__vo uint32_t AHB1RSTR;		//RCC AHB1 peripheral reset register
	__vo uint32_t AHB2RSTR;		//RCC AHB2 peripheral reset register
	__vo uint32_t AHB3RSTR;		//RCC AHB3 peripheral reset register
	__vo uint32_t RESERVED0;
	__vo uint32_t APB1RSTR;		//RCC APB1 peripheral reset register
	__vo uint32_t APB2RSTR;		//RCC APB2 peripheral reset register
	__vo uint32_t RESERVED1;
	__vo uint32_t RESERVED2;
	__vo uint32_t AHB1ENR;		//RCC AHB1 peripheral clock enable register
	__vo uint32_t AHB2ENR;		//RCC AHB2 peripheral clock enable register
	__vo uint32_t AHB3ENR;		//RCC AHB3 peripheral clock enable register
	__vo uint32_t RESERVED3;
	__vo uint32_t APB1ENR;		//RCC APB1 peripheral clock enable register
	__vo uint32_t APB2ENR;		//RCC APB2 peripheral clock enable register
	__vo uint32_t RESERVED4;
	__vo uint32_t RESERVED5;
	__vo uint32_t AHB1LPENR;	//RCC AHB1 peripheral clock enable in low power mode register
	__vo uint32_t AHB2LPENR;	//RCC AHB2 peripheral clock enable in low power mode register
	__vo uint32_t AHB3LPENR;	//RCC AHB3 peripheral clock enable in low power mode register
	__vo uint32_t RESERVED6;
	__vo uint32_t APB1LPENR;	//RCC APB1 peripheral clock enable in low power mode register
	__vo uint32_t APB2LPENR;	//RCC APB2 peripheral clock enable in low power mode register
	__vo uint32_t RESERVED7;
	__vo uint32_t RESERVED8;
	__vo uint32_t BDCR;			//RCC Backup domain control register
	__vo uint32_t CSR;			//RCC clock control & status register
	__vo uint32_t RESERVED9;
	__vo uint32_t RESERVED10;
	__vo uint32_t SSCGR;		//RCC spread spectrum clock generation register
	__vo uint32_t PLLI2SCFGR;	//RCC PLLI2S configuration register
	__vo uint32_t PLLSAICFGR;	//RCC PLL configuration register
	__vo uint32_t DCKCFGR;		//RCC dedicated clock configuration register
	__vo uint32_t CKGATENR;		//RCC clocks gated enable register
	__vo uint32_t DCKCFGR2;		//RCC dedicated clocks configuration register 2

}RCC_RegDef_t;

#define RCC										((RCC_RegDef_t*) RCC_BASEADDR)

/*
 * Clock Enable MACROs for GPIOx peripheral
 */

#define GPIOA_PCLK_EN()				((RCC->AHB1ENR) |= (1 << 0))
#define GPIOB_PCLK_EN()				((RCC->AHB1ENR) |= (1 << 1))
#define GPIOC_PCLK_EN()				((RCC->AHB1ENR) |= (1 << 2))
#define GPIOD_PCLK_EN()				((RCC->AHB1ENR) |= (1 << 3))
#define GPIOE_PCLK_EN()				((RCC->AHB1ENR) |= (1 << 4))
#define GPIOF_PCLK_EN()				((RCC->AHB1ENR) |= (1 << 5))
#define GPIOG_PCLK_EN()				((RCC->AHB1ENR) |= (1 << 6))
#define GPIOH_PCLK_EN()				((RCC->AHB1ENR) |= (1 << 7))

/*
 * Clock Enable MACROs for I2Cx peripheral
 */

#define I2C1_PCLK_EN()				((RCC->APB1ENR) |= (1 << 21))
#define I2C2_PCLK_EN()				((RCC->APB1ENR) |= (1 << 22))
#define I2C3_PCLK_EN()				((RCC->APB1ENR) |= (1 << 23))

/*
 * Clock Enable MACROs for USARTx peripheral
 */

#define USART1_PCLK_EN()			((RCC->APB2ENR) |= (1 << 4))
#define USART6_PCLK_EN()			((RCC->APB2ENR) |= (1 << 5))
#define USART2_PCLK_EN()			((RCC->APB1ENR) |= (1 << 17))
#define USART3_PCLK_EN()			((RCC->APB1ENR) |= (1 << 18))

/*
 * Clock Enable MACROs for SYSCFG peripheral
 */

#define SYSCFG_PCLK_EN()			((RCC->APB2ENR) |= (1 << 14))


/*
 * Clock Disable MACROs for GPIOx peripheral
 */

#define GPIOA_PCLK_DI()				((RCC->AHB1ENR) |= (0 << 0))
#define GPIOB_PCLK_DI()				((RCC->AHB1ENR) |= (0 << 1))
#define GPIOC_PCLK_DI()				((RCC->AHB1ENR) |= (0 << 2))
#define GPIOD_PCLK_DI()				((RCC->AHB1ENR) |= (0 << 3))
#define GPIOE_PCLK_DI()				((RCC->AHB1ENR) |= (0 << 4))
#define GPIOF_PCLK_DI()				((RCC->AHB1ENR) |= (0 << 5))
#define GPIOG_PCLK_DI()				((RCC->AHB1ENR) |= (0 << 6))
#define GPIOH_PCLK_DI()				((RCC->AHB1ENR) |= (0 << 7))

/*
 * Clock Disable MACROs for I2Cx peripheral
 */

#define I2C1_PCLK_DI()				((RCC->APB1ENR) |= (0 << 21))
#define I2C2_PCLK_DI()				((RCC->APB1ENR) |= (0 << 22))
#define I2C3_PCLK_DI()				((RCC->APB1ENR) |= (0 << 23))

/*
 * Clock Disable MACROs for USARTx peripheral
 */

#define USART1_PCLK_DI()			((RCC->APB2ENR) |= (0 << 4))
#define USART6_PCLK_DI()			((RCC->APB2ENR) |= (0 << 5))
#define USART2_PCLK_DI()			((RCC->APB1ENR) |= (0 << 17))
#define USART3_PCLK_DI()			((RCC->APB1ENR) |= (0 << 18))

/*
 * Clock Disable MACROs for SYSCFG peripheral
 */

#define SYSCFG_PCLK_DISABLE()			((RCC->APB2ENR) |= (0 << 14))

/*
 * 	MACROs to reset GPIOx peripheral
 */

#define GPIOA_REG_RESET()				do{ ((RCC->AHB1RSTR) |= (0 << 0))	;		((RCC->AHB1RSTR) &= ~(1 << 0))  ; }while(0)
#define GPIOB_REG_RESET()				do{ ((RCC->AHB1RSTR) |= (0 << 1))	;		((RCC->AHB1RSTR) &= ~(1 << 1))  ; }while(0)
#define GPIOC_REG_RESET()				do{ ((RCC->AHB1RSTR) |= (0 << 2))	;		((RCC->AHB1RSTR) &= ~(1 << 2))  ; }while(0)
#define GPIOD_REG_RESET()				do{ ((RCC->AHB1RSTR) |= (0 << 4))	;		((RCC->AHB1RSTR) &= ~(1 << 3))  ; }while(0)
#define GPIOE_REG_RESET()				do{ ((RCC->AHB1RSTR) |= (0 << 5))	;		((RCC->AHB1RSTR) &= ~(1 << 4))  ; }while(0)
#define GPIOF_REG_RESET()				do{ ((RCC->AHB1RSTR) |= (0 << 6))	;		((RCC->AHB1RSTR) &= ~(1 << 5))  ; }while(0)
#define GPIOG_REG_RESET()				do{ ((RCC->AHB1RSTR) |= (0 << 7))	;		((RCC->AHB1RSTR) &= ~(1 << 6))  ; }while(0)
#define GPIOH_REG_RESET()				do{ ((RCC->AHB1RSTR) |= (0 << 8))	;		((RCC->AHB1RSTR) &= ~(1 << 7))  ; }while(0)

//some generic MACROs

#define 	ENABLE 			1
#define 	DISABLE 		0
#define 	SET				ENABLE
#define 	RESET			DISABLE
#define 	GPIO_PIN_SET	SET
#define 	GPIO_PIN_RESET	RESET

/*
 * peripheral definitions ( peripheral bas addresses typecasted to xxx_RegDef_t)
 * we did these MACROs to make it easy for call
 */

#define GPIOA									((GPIO_RegDef_t*) GPIOA_BASEADDR)
#define GPIOB									((GPIO_RegDef_t*) GPIOB_BASEADDR)
#define GPIOC									((GPIO_RegDef_t*) GPIOC_BASEADDR)
#define GPIOD									((GPIO_RegDef_t*) GPIOD_BASEADDR)
#define GPIOE									((GPIO_RegDef_t*) GPIOE_BASEADDR)
#define GPIOF									((GPIO_RegDef_t*) GPIOF_BASEADDR)
#define GPIOG									((GPIO_RegDef_t*) GPIOG_BASEADDR)
#define GPIOH									((GPIO_RegDef_t*) GPIOH_BASEADDR)



#endif /* INC_STM32F446RE_H_ */
